CUDA_VISIBLE_DEVICES='0' python main_vctk.py --exp_dir ./checkpoint --meta normal --mode test --exp_name NAME OF MODEL
